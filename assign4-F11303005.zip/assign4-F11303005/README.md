# 🧨 Assignment 4-NS Shaft Plus

### Practice 1 – finish SpikyPlatform

### Practice 2 – finish FragilePlatform

### Practice 3 – finish HealPlatform

### Practice 4 – add sound effects to each Platforms

### 🌟 Extra Challenge – Make a cool ending for the game!
